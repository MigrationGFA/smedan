
       <!-- BEGIN Vendor JS-->
       <script src="<?php echo base_url('public/assets/app-assets/vendors/js/vendors.min.js'); ?>"></script>
    <!-- BEGIN: Page Vendor JS-->
    <script src="<?php echo base_url('public/assets/app-assets/vendors/js/forms/wizard/bs-stepper.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/app-assets/vendors/js/extensions/toastr.min.js'); ?>"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="<?php echo base_url('public/assets/app-assets/js/core/app-menu.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/app-assets/js/core/app.min.js'); ?>"></script>
    <script src="<?php echo base_url('public/assets/app-assets/js/scripts/customizer.min.js'); ?>"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
   <script src="<?php echo base_url('public/assets/app-assets/js/scripts/pages/app-ecommerce-checkout.min.js'); ?>"></script>
    
    <!-- END: Page JS--> 

 <script>
      $(window).on('load',  function(){
        if (feather) {
          feather.replace({ width: 14, height: 14 });
        }
      })
    </script>
  </body>
  <!-- END: Body-->

<!-- Mirrored from pixinvent.com/demo/vuexy-html-bootstrap-admin-template/html/ltr/vertical-menu-template/auth-login-cover.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 30 Nov 2021 09:28:38 GMT -->
</html>