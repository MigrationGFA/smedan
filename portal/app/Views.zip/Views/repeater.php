<div class="removeMoreot"><div data-repeater-item><div class="row d-flex align-items-end"><div class="col-md-3 col-12"><div class="mb-1"><label class="form-label" for="itemname">Name</label><input
                        type="text"
                        class="form-control"
                        id="itemname"
                        aria-describedby="itemname"
                        placeholder="Founders Name"
                        name="founderName[]"
                        
                      /></div></div><div class="col-md-1 col-12"><div class="mb-1"><label class="form-label" for="itemcost">Gender</label><input
                        type="text"
                        class="form-control"
                        id="itemcost"
                        aria-describedby="itemcost"
                        placeholder="F"
                        name="founderGender[]"
                        
                      /></div></div><div class="col-md-2 col-12"><div class="mb-1"><label class="form-label" for="itemquantity">Designation</label><input
                        type="text"
                        class="form-control"
                        id="itemquantity"
                        aria-describedby="itemquantity"
                        placeholder="CEO"
                        name="founderDesignation[]"
                       
                      /></div></div><div class="col-md-2 col-12"><div class="mb-1"><label class="form-label" for="itemquantity">Linkedin</label><input
                        type="text"
                        class="form-control"
                        id="itemquantity"
                        aria-describedby="itemquantity"
                        placeholder="url"
                        name="founderLinkedin[]"
                     
                      /></div></div><div class="col-md-2 col-12"><div class="mb-1"><label class="form-label" for="staticprice">Picture</label><input
                        type="file"
                        class="form-control"
                        id="itemquantity"
                        aria-describedby="itemquantity"
                        placeholder="Picture"
                        name="file[]"
                       
                      /></div></div><div class="col-12 col-sm-6 mb-1"><textarea
                  
                  class="form-control"
                  id="textarea-counter"
                  rows="3"
                  placeholder="Brief about this founder/Cofounder"
                  style="height: 100px"
				  name="founderAbout[]"
			
                >Brief about this founder/Cofounder</textarea></div><div class="col-md-2 col-12 mb-50"><div class="mb-1"><button class="btn btn-outline-danger text-nowrap px-1 removeFieldot" data-repeater-delete type="button"><i data-feather="x" class="me-25"></i></button></div></div></div><hr /></div></div>