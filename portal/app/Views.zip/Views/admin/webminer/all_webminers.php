<div class="content-wrapper">

<section class="content">
      <div class="row">
        <div class="col-xs-12">
            
          <div class="box">
              
            <div class="box-header">
              <h3 class="box-title">COHORTS</h3>
            </div>
            <!-- /.box-header -->
            
            <div class="box-body">
                <a href="<?php echo base_url(); ?>admin/add_cohort_participant/Microsoft" class="btn btn-info pull-right">+ Add Cohort Particpant</a>
                <br><br>
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>S/no</th>
                  <th>Startup</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
				  <th>Industry</th>
                  <th>Country</th>
                  <th>Payment</th>
                  <th></th>
                 
                </tr>
                </thead>
				<tbody>
                </tbody>
                
                <tfoot>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>